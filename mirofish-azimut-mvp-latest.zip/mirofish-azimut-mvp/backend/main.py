
from fastapi import FastAPI
from pydantic import BaseModel
from typing import List
import numpy as np

app = FastAPI()

class AgentConfig(BaseModel):
    id: int
    risk_tolerance: float

class Scenario(BaseModel):
    name: str
    inflation_shock: float
    rounds: int = 20
    agents: List[AgentConfig]

class SimulationResult(BaseModel):
    scenario: str
    rounds: int
    avg_panic_sell: List[float]

@app.post('/api/simulate', response_model=SimulationResult)
async def simulate_scenario(s: Scenario):
    n = len(s.agents)
    risk = np.array([a.risk_tolerance for a in s.agents])
    portfolio = np.ones(n) * 100.0
    reactions = []
    for r in range(s.rounds):
        panic = np.random.beta(2 + r * 0.1, 5, size=n) * s.inflation_shock * (1.0 - risk)
        sell_prob = np.clip(panic, 0.0, 1.0)
        portfolio *= (1.0 - sell_prob * 0.1)
        reactions.append(float(np.mean(sell_prob) * 100.0))
    return SimulationResult(scenario=s.name, rounds=s.rounds, avg_panic_sell=reactions)

@app.get('/api/health')
async def health():
    return {"status": "ok"}
