
# MiroFish Azimut MVP

Backend FastAPI per simulare uno stress test di mercato basato su shock di inflazione e tolleranza al rischio degli agenti, e frontend HTML/JS minimale per lanciare la simulazione e visualizzare il panic sell medio nel tempo.

## Avvio backend

```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload
```

## Avvio frontend

Apri `frontend/index.html` nel browser e assicurati che il backend giri su `http://localhost:8000`.
```
